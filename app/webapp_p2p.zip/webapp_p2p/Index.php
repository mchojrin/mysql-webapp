<!DOCTYPE html>
<!-- Index.php 
This is a comment. Comments are not displayed in the browser.
To run it as a php file:
http://localhost/webapp_p2p/Index.php
-->

<html lang='en'>
<head>
    <meta charset="UTF-8" /> 
    <title>
        Index.php
    </title>
    <link rel="stylesheet" type="text/css" HREF="Style.css" >
</head>
<body background= "geneticsdark.jpg" alt="Bioinformatics website" style="width:1400px;height:800px;" >
<h1>
    Use prod_p2p Database
</h1>
<br><br>
	<input Type="button" value="Go Back to Home Page" class="button" onclick="window.location.href='ProjectPresentation.php'"> 
<br>
<p> This is the main reports search page that leads users to several search forms that generate different types of reports.
</p>
<ol>

<li>
<p>For details about Genes in the database and the proteins they contain, please press <a href="Genes.php"><b>here</b></a>.</P>
<li>
<p>For a list of synonyms of Proteins associated with a corresponding disease, please press <a href="ProteinsDiseases.php"><b>here</b></a>.</P>
<li>
<p>For more information about the database, please press <a href="Information.php"><b>here</b></a>.</P>
</ol>
<br>

</body>
</html>