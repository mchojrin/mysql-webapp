<!DOCTYPE html>
<!--PracticalApplications.php 
This is a comment. Comments are not displayed in the browser.
To run it as a php file:
http://localhost/webapp_p2p/PracticalApplications.php
-->
<html>
<head>
    <title>
       PracticalApplications.php
    </title>
	<link rel="stylesheet" type="text/css" HREF="Style.css" >
</head>
<body background= "geneticsdark.jpg" alt="Bioinformatics website" style="width:1400px;height:800px;">

<h1>
    Practical Applications
	
</h1>
<br>
	<input Type="button" value="Go Back to Website Documentations Page" class="button" onclick="window.location.href='WebsiteDocumentation.php'"> 
<hr>
<p>
	
	<br><br>My database provides an up-to-date, comprehensive body of protein information.
	<br><br>People can explore the published literature for proteins related to specific diseases
	<br><br>It can also aid research and analysis as the data collected is organized and interpreted in a way that is easy to access and use.
	

</p>
<br>
<br>
</body>
</html>
