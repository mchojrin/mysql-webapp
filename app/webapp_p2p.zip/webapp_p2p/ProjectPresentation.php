<!DOCTYPE html>
<!--ProjectPresentation.php 
This is a comment. Comments are not displayed in the browser.
To run it as a php file:
http://localhost/webapp_p2p/ProjectPresentation.php
-->

<html lang='en'>
<head>
    <meta charset="UTF-8" /> 
    <title>
        ProjectPresentation.php
    </title>
    <link rel="stylesheet" type="text/css" HREF="Style.css">
</head>
<body background= "geneticsdark.jpg" alt="Bioinformatics website" style="width:1400px;height:800px;" >
<h1>
    Protein to Phenotype (P2P) Web Application
</h1>
<br>
<ul>
	<li>
	<p><b>Hi! I'm Prakash.</b></P>
    </li>
    <li>
	<p><b>Here are my web app details:</b></P>
    </li>
</ul>

<ol>

<li>
<p><a href="WebsiteDocumentation.php"><b>App Documentation</b></a></p></li>
<li>
<p><a href="Index.php"><b>Reports</b></a></p></li>
<li>
<p><a href="FutureWork.php"><b>Future Work</b></a></p></li>
</ol>
</body>
</html>