<!DOCTYPE html>
<!-- FutureWork.php 
This is a comment. Comments are not displayed in the browser.
To run it as a php file:
http://localhost/webapp_p2p/FutureWork.php
-->
<html>
<head>
    <title>
        FutureWork.php
    </title>
	<link rel="stylesheet" type="text/css" HREF="Style.css" >
</head>
<body background= "geneticsdark.jpg" alt="Bioinformatics website" style="width:1400px;height:800px;">

<h1>
    Future Work

</h1>
<br>
	<input Type="button" class="button" value="Go Back to Home Page" onclick="window.location.href='ProjectPresentation.php'"> 
<hr>
<ol>
<br/>
<br/>
	<li> <b>Data Repository</b>
	<p> -    This database I created can be expanded:
	<br/> -    The size of the database when increased can cover a breadth of diseases thereby providing...
	<br/>... more protein and gene information
	<br/> -    When as much information as the UniProt website itself is stored, I can query for information...
	<br/>...rather than visiting the website.
	</p>
	</li>
	<br/>
	<br/>
	<li> <b>Website: One place for all</b>
	<p>  -    Provided I accumulate all the information, I can create my own website which has details of...
	<br/> ...proteins, genes, disease and also disease ontology information. One stop for all information.
	<br/>  -    To gather the same or similar data, one can just visit the website I create rather than...
	<br/> ... visiting 3-4 different resources as I did during creating this web application.
	</p>
	</li>
	
</ol>
<br>
<br>
</body>
</html>
